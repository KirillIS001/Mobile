package com.example.start_prj_3

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
